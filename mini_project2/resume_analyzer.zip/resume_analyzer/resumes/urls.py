from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ResumeViewSet, AnalysisResultViewSet

router = DefaultRouter()
router.register(r'resumes', ResumeViewSet)
router.register(r'analyses', AnalysisResultViewSet)

urlpatterns = [
    path('', include(router.urls)),
]